import cv2
import numpy as np
import time

width = 640
height = 480
fps = 24
# ! video/x-gdp, format=BGR, width=640, height=480,framerate=24/1 \
gst_sender_writer = cv2.VideoWriter("appsrc \
! videoconvert \
! x264enc speed-preset=ultrafast tune=zerolatency byte-stream=true threads=1 key-int-max=15 intra-refresh=true  \
! h264parse \
! gdppay \
! tcpclientsink host=1.249.212.151 port=5000 sync=false", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)), True)

# gst_sender_writer = cv2.VideoWriter("appsrc \
# ! video/x-raw, format=(string)I420  \
# ! nvvidconv \
# ! 'video/x-raw(memory:NVMM),width=640,height=480' \
# ! nvv4l2h264enc insert-sps-pps=1 idrinterval=15  \
# ! h264parse \
# ! gdppay \
# ! tcpclientsink host=1.249.212.151 port=5000 sync=false", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)), True)

gst_str_rtp = "appsrc ! videoconvert ! x264enc noise-reduction=10000 tune=zerolatency byte-stream=true threads=4 " \
              " ! h264parse ! rtph264pay ! udpsink host=127.0.0.1 port=5000"
frame_width = 640
frame_height = 480



def test_image():
    img = np.zeros((480,640,3), np.uint8)
    cv2.putText(img, str(time.time()), (100,100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
    return img

while 1:
    try:
        img = test_image()
        img = cv2.resize(img, dsize=(640, 480))
        # cv2.imshow("test send", img)
        # img = cv2.cvtColor(img, cv2.COLOR_BGR2YUV_I420);
        gst_sender_writer.write(img)
        cv2.waitKey(1)

        time.sleep(1./20)
        
        #out.write(img)
    except Exception as ex:
        print(ex)