#! /usr/bin/python
# Gwanjun Shin
# VDCL FMTC Remote - tcp car manager (sending video, meta and receiving control)
PACKAGE = 'vdcl_remote'
import cv2
import numpy as np
from collections import deque
import time
import traceback
from typing import Any, Dict, Tuple
import rospy
from dynamic_reconfigure.server import Server
from vdcl_remote.cfg import vdcl_remoteConfig
import math
import os
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image, CameraInfo, CompressedImage
from std_msgs.msg import Float32MultiArray, MultiArrayDimension, MultiArrayLayout, Float32
from chassis_msgs.msg import Chassis
from acu_new_ioniqw_msgs.msg import acu_new_ioniqw, acu_new_ioniqw_TX
from inertial_labs_msgs.msg import ilgps_RTtype
# For rviz
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from std_msgs.msg import Header, ColorRGBA
import cv2
import threading
from multiprocessing import Process, Queue , Pipe 
from csv import excel
from datetime import datetime
import socket
import configparser
import os, sys, time
import threading
import pickle
import uuid
import datetime
# TODO : implement multiprocessing, python threading is fraud

os.system('echo "vdcl" | sudo -S sysctl -w kernel.sched_rt_runtime_us=-1')
os.system(f"echo 'vdcl' | sudo -S chrt -rr -p 99 {os.getpid()}")


config = configparser.ConfigParser()
curWd = os.path.dirname(os.path.realpath(__file__))
print(curWd)
config.read( os.path.join(curWd, '../cfg/network.cfg') )
    
SERVER_IP = config.get('network', 'SERVER_IP')
PORT = config.get('network', 'PORT')
LIFECYCLE = float(config.get('network', 'LIFECYCLE'))
PAIR_KEY = "vdcl1234"
VIDEO_COMM_MODE = config.get('network', 'VIDEO_COMM_MODE') #tcp or udp


class car_control_struct:
    swa = 0.0
    accel = 100.0
    brake = 100.0

class remote_manager():
  # Print control status and connection status

    def __init__(self):
        self.control_status = False # Default is On-Device
        self.car_fail_signal = False # From ROS-VDCL Logic
        self.connection_status = False # Default is not connected
        
        # Make network thread
        self.network_inst = control_server()
        
        self.network_thread = threading.Thread(target=self.network_inst.loop)
        
        
        self.network_thread.daemon = True
        self.network_thread.start()
        

        # Make ROS thread
        #self.ros_comm = ros_comm()
        
        
        # Image Server
        self.image_server = image_server()
        
        self.lifetime = 0
        
        
        # Some ROS Init
        
        
    def _print(self):
        # Print colored control status and connection status, red is false, green is true
        # and flush the print buffer
        datatime = datetime.datetime.now().strftime("%H:%M:%S")
        mode_notice = "" if sN.OPERATING_MODE == 0 else " (TEST MODE ENABLED)"
        print("[FMTC Remote Client] \033[42m" + mode_notice + "\033[0m        [ " + datatime + "] ")
        print("")
        print("[CAR Side INFO]")
        if self.control_status:
            print("     \033[92m[Control Status] Remote\033[0m")
        else:
            # Orange color
            print(f"     \033[93m[Control Status] On-Device\033[0m - LIFETIME [{self.lifetime}]")
            
        ACC_AVAIL = "\033[92mACC ON\033[0m" if sN.car.ACC_Enable_Status else "\033[91mACC OFF\033[0m"
        MDPS_AVAIL = "\033[92mMDPS ON\033[0m" if sN.car.MDPS_Enable_Status else "\033[91mMDPS OFF\033[0m"
        #print("     \033[91m[Module Status]\033[0m {ACC_AVAIL}| {MDPS_AVAIL}")
        
        if self.car_fail_signal:
            print("     \033[91m[Car State] Fault\033[0m")
        else:
            print("     \033[92m[Car Fail Signal] Normal\033[0m")
            
        if self.image_server.send_status:
            print("     \033[92m[Image Server] On\033[0m")
        else:
            print("     \033[91m[Image Server] Off\033[0m")
            
        print("[Network INFO]")
        if self.network_inst.connection_status:
            print("     \033[92m[Connection Status] Connected\033[0m")
            print("     \033[92m[Connection Uptime] {}s\033[0m".format(self.network_inst.get_connection_uptime()))
            
        else:
            print("     \033[91m[Connection Status] Disconnected\033[0m")
            print("     \033[91m[Connection Uptime] 0s\033[0m")
        
        if self.control_status:
            print("[CONTROL INFO]")
            self._make_control_tb()

            
        print("[Job]")
        print("     {}".format(self.network_inst.current_job))
        
        
        print("[Last Message]")
        print("     {}".format(self.network_inst.last_recv_message))
        
        
    def _make_control_tb(self):
                # make table for control info
        # |     | Desired | Real | Error |
        # | Ax  |         |      |       |
        # | Steer  |         |      |       |
        # | Brake  |         |      |       |

        self.desired_ax = sN.car.Ax_tx_cmd
        self.real_ax = sN.car.Ax_Cmd
        self.desired_steer = self.network_inst.control_swa
        self.real_steer = sN.car.MDPS_Steering_Angle
        
        self.real_speed = 0.0 # TODO: get real speed from ROS

        # print(f"        Data  | Desired | Real | Error ")
        # print(f"        Accel | {round(self.network_inst.control_accel, 2):7} |")
        # print(f"        Brake | {round(self.network_inst.control_brake, 2):7} |")
        # print(f"        Ax    | {round(self.desired_ax, 2):7} | {round(self.real_ax, 2):4} | {round(self.desired_ax - self.real_ax, 2)} ")
        # print(f"        Steer | {round(self.desired_steer, 2):7} | {round(self.real_steer, 2):4} | {round(self.desired_steer - self.real_steer, 2)} ")
        # print(f"        Speed | {-1:7} | {round(self.real_speed, 2):4} | --- ")
        pass
        
        
        
    def _flush(self):
        # Flush Terminal
        os.system('cls' if os.name == 'nt' else 'clear')
        
        
    def _control_check(self):
        if self.network_inst.control_request and sN.car.ACC_Enable_Status and sN.car.MDPS_Enable_Status and self.connection_status:
            # Then we can control the car iff ACU_Tx node is running
            self.control_status = True
            
        elif self.network_inst.control_request and sN.OPERATING_MODE == 1 and self.network_inst.connection_status:
            self.control_status = True
            
        else :
            self.control_status = False
            self.network_inst.control_accel = 100.0
            self.network_inst.control_brake = 100.0
            self.network_inst.control_swa = 0.0
            #pN.releseControl()
            
        self._control()


        pass

    def _control(self):
        if self.control_status and self.network_inst.connection_status:
            cmd_msg = Point()
            cmd_msg.y = float(self.network_inst.control_accel)
            cmd_msg.x = float(self.network_inst.control_swa)
            cmd_msg.z = float(self.network_inst.control_brake)
            
            pN.controlPub.publish(cmd_msg)
        else:

            cmd_msg = Point()
            cmd_msg.y = 100.0
            cmd_msg.x = 0.0
            cmd_msg.z = 100.0
            
            pN.controlPub.publish(cmd_msg)

    def loop(self):
        # while loop, if get ctrl+c, close the socket and give ros topic a last message
        # and exit the program
        while rospy.is_shutdown() == False:
            try:
                self._control_check()
                self._print()
                time.sleep( LIFECYCLE )
                self._flush()
                self.lifecycle_manager()
                    
            except KeyboardInterrupt:
                self.network_inst.current_job = "Closing..."
                self.network_inst.close()
                self.ros_comm.close()
                #print("Bye")
                sys.exit(-1)
                
    def lifecycle_manager(self):
        if not self.network_inst.connection_status and self.lifetime > 5000:
            sys.exit(-1)
        if not self.network_inst.connection_status:
            self.lifetime += 1
        else:
            self.lifetime = 0
        	       
        
class control_server():
    connection_status = False
    current_job = ""
    last_recv_message = ""
    
    control_request = False
    control_ax = 0
    control_swa = 0
    

    
    def __init__(self):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
    def auth(self):
        # send pairkey to server
        self.current_job = "On Authentication Process"
        self.send_pass(PAIR_KEY)
        s, data = self.receive()
        self.current_job = "Authentication Result: {data}".format(data=data)
        
        #print(data)
        
        if data == b'OK':
            time.sleep(1)
            return True
        elif data == b'FAIL':
            time.sleep(1)
            return False
    
    ## alive health check by echoing back the received message
    def is_alive(self):
        if self.connection_status:
            _uuid = str(uuid.uuid4())
    
            self.send_pass('alive:{_uuid}'.format(_uuid=_uuid))
            
    def send_car_info(self):
        # if self.connection_status:
        #     self.send(pickle.dumps(sN.car))
        # send car meta data and status code
        # 1 of all good, -1 is unknown error -30 is illegal request acc or mdps is not enabled
       
        t_data = sN.car.get_dict()
        self.send(pickle.dumps(t_data))

       
        pass
        
    def loop(self):
        while rospy.is_shutdown() == False:
            
            if not self.connection_status:
                self.get_connection()

                
            try:
                t1 = time.time()
                #print("loop")
                s_code, data = self.receive()
                
                if s_code == 0: # expected control format
                    
                    if data:
                        data = pickle.loads(data)
                        self.safety_check(t1, data)

                        #rint(data)
                        
                        t_control_request = bool(data.get("control_request"))
                        t_control_accel = float(data.get("control_accel"))
                        t_control_brake = float(data.get("control_brake"))
                        t_control_swa = float(data.get("control_swa"))

                        if t_control_accel != None and t_control_brake != None and t_control_swa != None and t_control_request != None:
                            self.control_accel = t_control_accel
                            self.control_brake = t_control_brake
                            self.control_swa = t_control_swa
                            self.control_request = t_control_request
                        else:
                            self.control_accel = 100
                            self.control_brake = 100
                            
                            self.control_swa = 0
                            self.control_request = False
                            
                            #self.current_job = f"Now in Remote Control Mode"

                    
                elif s_code == 1: # string not valid control format
                    data = data
                    
                # self.is_alive()
                
                self.send_car_info()
                
                      
                #self.last_recv_message = data
                    
                # else:
                #     self.current_job = print("\033[91mNo Data!, Not expected\033[0m")
                #     self.close()
                #     break
            except KeyboardInterrupt:
                self.close()
                break
            
            except Exception as ex:
                print(ex)
                self.connection_status = False
                continue # For reconnect

    def safety_check(self, t1, data):
        # check if the received message is too old
        t2 = time.time()
        if t2 - t1 < sN.MSG_LIFE_TIME:
            #self.current_job = f"Control Ready - Awaiting Request"
            pass
        else:
            self.current_job = "Delayed - {} sec".format(round(t2-t1, 3))
            
            
        # Check message is eligible to control


    def get_connection(self):
        # try to connect server, if port is used, wait 1 sec and try again, until connection is established
        while not self.connection_status and not rospy.is_shutdown():
            try:
                self.current_job = "connecting to FMTC Server"
                self.client_socket.connect((SERVER_IP, int(PORT)))
                
                if not (self.auth()):
                    self.current_job = "Authentication Failed"
                    self.client_socket.shutdown(socket.SHUT_RDWR)

                    raise Exception("Authentication Failed")
                
                self.connection_status = True
                self.connection_start_time = time.time()
            
            except KeyboardInterrupt:
                self.close()
                sys.exit()    
            
            # Socket is used, kill the occupied process by lsof 
            except Exception as ex: 
                #print("Socket is used, kill the occupied process by lsof")
                #os.system("lsof -i :{}".format(PORT))
                #os.system("kill -9 $(lsof -t -i:{})".format(PORT))
                #rint(ex)
                self.current_job = "On TCP Connection : " + str(ex)
                traceback.print_exc()
                time.sleep(3)
                self.__init__()
                
        self.current_job = "connection established"
        return self.connection_status
    
    def get_connection_uptime(self):
        if self.connection_status:
            return round(time.time() - self.connection_start_time, 0)
        else:   
            return 0

    def send_pass(self, msg):
        self.client_socket.send(msg.encode())

    def send(self, msg):
        #print("send", msg)
        self.client_socket.send(msg)

    def receive(self):
        try:
            data = self.client_socket.recv(1024)
            return 0, data # Pickle
        except:
            data = self.client_socket.recv(1024).decode()
            return 1, data # Normal message
    def close(self):
        self.client_socket.close()


class image_server():
    def __init__(self):

        # two trials; 3 gst sending vs 1 gst with 3 panorama image
        self.MODE = "single" # panorama, gst

        # self.gst_sender_writer = cv2.VideoWriter("appsrc ! video/x-raw,format=BGR ! queue ! videoconvert ! x264enc insert-vui=1 ! h264parse ! rtph264pay ! udpsink port=5000", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height))) 
        
        # writer = cv2.VideoWriter("appsrc ! video/x-raw,format=BGR ! queue ! videoconvert ! video/x-raw,format=BGRx ! nvvidconv ! nvv4l2h264enc insert-sps-pps=1 insert-vui=1 ! h264parse ! rtph264pay ! udpsink port=5001", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height))) 
        # test gst image with tcp host = 1.249.212.151:5000 

        # env config (test)

        self.last_img = None

        fps = 22
        if self.MODE == "single":
            width = 1280
            height = 720
        else:
            width = 640*3
            height = 480

        if VIDEO_COMM_MODE == 'udp':
            self.gst_sender_writer = cv2.VideoWriter("appsrc \
                ! timeoverlay \
                ! videoconvert \
                ! video/x-raw,format=BGRx \
                ! nvvidconv \
                ! nvv4l2h265enc maxperf-enable=1 idrinterval=1 insert-sps-pps=1 insert-vui=1 bitrate=3000000 preset-level=4 MeasureEncoderLatency=1 \
                ! video/x-h265,stream-format=(string)byte-stream \
                ! h265parse config-interval=1 \
                ! rtph265pay \
                ! udpsink host=1.249.212.207 port=5118 sync=false", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)), True)
        
        
        elif VIDEO_COMM_MODE == 'tcp':
            
            self.gst_sender_writer = cv2.VideoWriter("appsrc is-live=true\
            ! videoconvert \
            ! video/x-raw,format=BGRx \
            ! nvvidconv \
            ! nvv4l2h264enc maxperf-enable=1 idrinterval=15 insert-sps-pps=1 insert-vui=1 bitrate=4500000 preset-level=4 MeasureEncoderLatency=1 \
            ! video/x-h264,stream-format=(string)byte-stream \
            ! h264parse \
            ! rtph264pay \
            ! gdppay \
            ! tcpclientsink host=1.249.212.207 port=5118 sync=false", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)), True)

        
        avmSize = (260, 480) # real size is 720 480 
        self.avm_udp_writer = cv2.VideoWriter("appsrc \
                ! timeoverlay \
                ! videoconvert \
                ! video/x-raw,format=BGRx \
                ! nvvidconv \
                ! nvv4l2h265enc maxperf-enable=1 idrinterval=1 insert-sps-pps=1 insert-vui=1 bitrate=2500000 preset-level=4 MeasureEncoderLatency=1 \
                ! video/x-h265,stream-format=(string)byte-stream \
                ! h265parse config-interval=1 \
                ! rtph265pay \
                ! udpsink host=1.249.212.207 port=5000 sync=false", cv2.CAP_GSTREAMER, 0, float(20), (int(avmSize[0]),int(avmSize[1])), True)


        # elif VIDEO_COMM_MODE == 'tcp':

        #     self.gst_sender_writer = cv2.VideoWriter("appsrc is-live=true\
        #     ! videoconvert \
        #     ! x264enc insert-vui=true bitrate=5000 tune=zerolatency byte-stream=true speed-preset=ultrafast sliced-threads=true \
        #     ! rtph264pay \
        #     ! gdppay \
        #     ! tcpclientsink host=127.0.0.1 port=5118 sync=false", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)), True)

        #self.gst_sender_writer = cv2.VideoWriter("appsrc ! 'video/x-raw, width=(int)1920, height=(int)480,framerate=24/1' ! x264enc insert-vui=true bitrate=100000 tune=zerolatency  ! h264parse ! gdppay ! tcpclientsink host=1.249.212.151 port=6000", cv2.CAP_GSTREAMER, 0, float(fps), (int(width),int(height)))
        # then receive with gst-launch-1.0 tcpclientsrc host=  port=5000 ! gdpdepay ! rtph264depay ! avdec_h264 ! videoconvert ! autovideosink sync=false 
        # runner thread
        self.runner_daemon = threading.Thread(target = self.runner)
        self.runner_daemon.daemon = True
        self.runner_daemon.start()
        
        # init shared status variable
        self.send_status = False
         

    # simple opencv test image with current time
    def test_image(self):
        img = np.zeros((720,1280,3), np.uint8)
        cv2.putText(img, str(time.time()), (100,100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
        return img
    
    def panorama_image(self):
        # get 3 images from 3 cameras
        try:
            front_frame = sN.frontimageQ.pop()
        except:
            front_frame = self.test_image()
        try:
            left_frame = sN.flimageQ.pop()
        except:
            left_frame = self.test_image()
        try:
            right_frame = sN.frimageQ.pop()
        except:
            right_frame = self.test_image()
        
        # resize to 480x640
        front_frame = cv2.resize(front_frame, (640,480)) 
        left_frame = cv2.resize(left_frame, (640,480))
        right_frame = cv2.resize(right_frame, (640,480))
        
        # hstack 3 images
        img = np.hstack((left_frame, front_frame, right_frame))

        # add time to image
        cv2.putText(img, str(time.time()), (100,100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2, cv2.LINE_AA)
        
        return img

    def single_image(self):
        # get image from front camera
        try:
            img = sN.frontimageQ.pop()
        except:
            if  self.last_img is None:
                img = self.test_image()
            else:
                img = self.last_img

        self.last_img = img

        front_frame = cv2.resize(img, (1280,720)) 

        return front_frame
    
    def avm_image(self):
        try:
            img = sN.avmimageQ.pop()
        except:
            img = self.test_image()

        img = img[:, :260]
        img = cv2.resize(img, (260,480)) 

        return img

    def runner(self):
        while rospy.is_shutdown() == False:
            
            if self.MODE == "single":
                # img = self.test_image()
                img = self.single_image()

            elif self.MODE == "panorama":
                
                # get image availability
                if len(sN.frontimageQ) == 0 or len(sN.flimageQ) == 0 or len(sN.frimageQ) == 0:
                    continue
                
                img = self.panorama_image()

            else:
                img = self.test_image()

            
            self.send_status = True

            self.gst_sender_writer.write(img)

            # can we get resulkt from gst_sender_writer?
            # print(self.gst_sender_writer.isOpened())

            avmImage = self.avm_image()
            self.avm_udp_writer.write(avmImage)


            time.sleep(1. / 20) # 24fps

        self.send_status = False

    
class pubNode():
    def __init__(self):
        
        # self.pubLanePub = rospy.Publisher('/vdcl_remote/marker/lane', MarkerArray, queue_size=1)
        # self.planLinePub = rospy.Publisher('/vdcl_remote/marker/plan', MarkerArray, queue_size=1)
        # self.leadPub = rospy.Publisher('/vdcl_remote/marker/lead', MarkerArray, queue_size=1)
        
        # self.leadyPub = rospy.Publisher('/vdcl_remote/lead/dist', Float32, queue_size=1)
        # self.leadVxPub = rospy.Publisher('/vdcl_remote/lead/vx', Float32, queue_size=1)
        
        # self.overlayPub = rospy.Publisher('/vdcl_remote/overlay/image', CompressedImage, queue_size=1)
        
        self.controlPub = rospy.Publisher('/vdcl_remote_acuTX',Point,queue_size=1) # or UDP_input as legacy
        
        pass
    
    def releseControl(self):
        self.controlPub.publish(Point(0,100,100))
        
        # TODO : deactivate ACC and MDPS Module
        
        
        
class car_status_struct():
    def __init__(self):
        self.MDPS_Enable_Status = False
        self.MDPS_Steering_Angle = 0.0
        self.ACC_Enable_Status = False
        self.Ax_Cmd = 0.0        
        self.Emergency_Stop_Status = False
        self.Vx = 0.0 #kph
        self.SAS_angle = 0.0

        self.gps_x = 0.0
        self.gps_y = 0.0
        
        self.Ax_tx_cmd = 0.0 # From CAR ACU

    def get_dict(self):
        return self.__dict__
        

class subNode():
    def __init__(self):
        # compressed image

        # temp hard coding : 
        # front left : /arena_camera_node_fl/image_raw/compressed
        # front right : /arena_camera_node_fr/image_raw/compressed
        # front center : /arena_camera_node_front/image_raw/compressed
        
        self.car = car_status_struct()

        
        self.bridge = CvBridge()
        config_daemon = Server(vdcl_remoteConfig, self.reconfigure_callback)

        spin_daemon = threading.Thread(target = self.ros_spin, daemon=True)
        spin_daemon.start()
        
        self.fronapc_structt_image = None
        self.frontimageQ = deque(maxlen=1)
        self.flimageQ = deque(maxlen=1)
        self.frimageQ = deque(maxlen=1)
        self.avmimageQ = deque(maxlen=1)
        
        # get Safety Param
        self.MAX_AX = float(rospy.get_param("/vdcl_remote/SAFETY_Max_Ax", 2))
        self.MAX_VX = float(rospy.get_param("/vdcl_remote/SAFETY_Max_Vx", 20))
        self.OPERATING_MODE = int(rospy.get_param("/vdcl_remote/MODE", 0)) # 0 for deploy (max safety), 1 for test (no safety)
        self.MSG_LIFE_TIME = float(rospy.get_param("/vdcl_remote/MSG_LIFE_TIME", 0.05))

        self.frontImageSub = rospy.Subscriber("/front_wide_camera/image_raw/compressed", CompressedImage, self.front_callback, queue_size=1)
        self.frImageSub = rospy.Subscriber("/arena_camera_node_fr/image_raw/compressed", CompressedImage, self.fr_callback, queue_size=1)
        self.flImageSub = rospy.Subscriber("/arena_camera_node_fl/image_raw/compressed", CompressedImage, self.fl_callback, queue_size=1)

        self.vdcl_avmSub = rospy.Subscriber("/svm/image_raw/compressed", CompressedImage, self.avmcallback, queue_size=1)
        self.avmStatus = False
        self.chassis_sub = rospy.Subscriber("/chassis", Chassis, self.chassis_callback)
        self.acu_sub = rospy.Subscriber("/acu_new_ioniqw",acu_new_ioniqw,self.acu_callback)
        self.acuTX_sub = rospy.Subscriber("/acu_new_ioniqw_TX",acu_new_ioniqw_TX,self.acuTX_callback)
        self.gps_cb = rospy.Subscriber("/ilgps_utm", ilgps_RTtype, self.gps_cb)
        
    def chassis_callback(self, data):
        self.car.Vx = round(data.whl_spd_fl,1)
        self.car.SAS_angle = round(data.sas_angle,1)
        pass
        
    def acu_callback(self, data):
        self.car.MDPS_Enable_Status = bool(data.MDPS_Module_Stat)
        self.car.ACC_Enable_Status = bool(data.ACC_Module_Stat)
        self.car.Emergency_Stop_Status = bool(data.EMR_STOP_Enable_Report)
        self.car.Ax_Cmd = float(data.Ax_cmd_Report)
        self.car.MDPS_Steering_Angle = float(data.SWA_Report)
        
    def acuTX_callback(self, data):
        self.car.Ax_tx_cmd = float(data.Ax_cmd)

    def gps_cb(self, data):
        self.car.gps_x = data.X_RT
        self.car.gps_y = data.Y_RT

        
    def avmcallback(self, data):
        try:
            self.avmStatus = True
            bgr_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
            self.avmimageQ.append(bgr_image)

        except Exception as e:
            self.avmStatus = False
            pass
        
    def front_callback(self, data):
        # cv brdige to convert ros image to cv2 image
        try:
            bgr_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
            # self.front_image = self.imgProcConfig(bgr_image)
            # # check topics is far far from current time
            self.frontimageQ.append(bgr_image)
            if (rospy.Time.now() - data.header.stamp).to_sec() > 0.08:
                
                #rospy.logfatal(f"{[PACKAGE]} Image Integrity Check Failed : Too Old Image")
                #self.frontimageQ.clear()
                return
            
        except Exception as e:
            assert False, "{PACKAGE} {e}".format(PACKAGE=PACKAGE, e=e)

    def fr_callback(self, data):
        # cv brdige to convert ros image to cv2 image
        try:
            bgr_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
            # self.front_image = self.imgProcConfig(bgr_image)
            # # check topics is far far from current time
            self.frimageQ.append(bgr_image)
            if (rospy.Time.now() - data.header.stamp).to_sec() > 0.08:
                
                #rospy.logfatal(f"{[PACKAGE]} Image Integrity Check Failed : Too Old Image")
                #self.frimageQ.clear()
                return
            
        except Exception as e:
            assert False, "{PACKAGE} {e}".format(PACKAGE=PACKAGE, e=e)

    def fl_callback(self, data):
        # cv brdige to convert ros image to cv2 image
        try:
            bgr_image = self.bridge.compressed_imgmsg_to_cv2(data, "bgr8")
            # self.front_image = self.imgProcConfig(bgr_image)
            # # check topics is far far from current time
            self.flimageQ.append(bgr_image)
            if (rospy.Time.now() - data.header.stamp).to_sec() > 0.08:
                
                #rospy.logfatal(f"{[PACKAGE]} Image Integrity Check Failed : Too Old Image")
                #self.flimageQ.clear()
                return
            
        except Exception as e:
            assert False, "{PACKAGE} {e}".format(PACKAGE=PACKAGE, e=e)
            
    def double_feeder(self):
        # return two consecutive temporal input of front image
        if len(self.imageQ) == 2:
            return np.array(self.imageQ)
        else:
            return None
            
    # def imgProcConfig(self, img):
    #     _img = cv2.resize(img, dsize = (512, 256))
    #     img_yuv = cv2.cvtColor(_img, cv2.COLOR_BGR2YUV_I420)
    #     H = (img_yuv.shape[0]*2)//3
    #     W = img_yuv.shape[1]
    #     parsed = np.zeros((6, H//2, W//2), dtype=np.uint8)
    #     parsed[0] = img_yuv[0:H:2, 0::2]
    #     parsed[1] = img_yuv[1:H:2, 0::2]
    #     parsed[2] = img_yuv[0:H:2, 1::2]
    #     parsed[3] = img_yuv[1:H:2, 1::2]
    #     parsed[4] = img_yuv[H:H+H//4].reshape((-1, H//2,W//2))
    #     parsed[5] = img_yuv[H+H//4:H+H//2].reshape((-1, H//2,W//2))
    #     return parsed
        
    def reconfigure_callback(self, config, level):
        '''
        struct of config
        overlay_image : bool
        overlay_text : bool
        RPY : float[3] as str
        model : int
        runtime : str
        '''
        self.apc_config = config
    
        return config
    
    def ros_spin(self):
        rospy.spin()
    
        
        
        
class vision_calibration():

    def __init__(self, rpy, dist):
        height = 0.0
        view_from_road = self.eulerAnglesToRotationMatrix(rpy) # [R ,P, Y]
        self.extrinsic_matrix = np.hstack((view_from_road, [[0], [height], [0]]))[:,:3]
        
        self.zoom = sN.apc_config.cam_H / 640.
        self._CALIB_BB_TO_FULL = np.asarray([
        [self.zoom, 0., 0.],
        [0., self.zoom, 0.],
        [0., 0., 1.]])
        
        device_frame_from_view_frame = np.array([
        [ 0.,  0.,  1.],
        [ 1.,  0.,  0.],
        [ 0.,  1.,  0.]
        ])
        view_frame_from_device_frame = device_frame_from_view_frame.T
        focal = sN.apc_config.focal
        full_size = (sN.apc_config.cam_H, sN.apc_config.cam_V)
        _INTRINSICS = np.array([
            [focal, 0., full_size[0] / 2.],
            [0., focal, full_size[1] / 2.],
            [0., 0., 1.]
            ])

        
    def car_space_to_ff(self, x, y, z):
        car_space_projective = np.column_stack((x, y, z)).T
        ep = self.extrinsics_matrix.dot(car_space_projective)
        kep = self.intrinsic.dot(ep)
        return (kep[:-1, :] / kep[-1, :]).T

    def eulerAnglesToRotationMatrix(self, theta) :

        R_x = np.array([[1.,        0.,                  0.                   ],
                        [0.,         math.cos(theta[0]), -math.sin(theta[0]) ],
                        [0.,         math.sin(theta[0]), math.cos(theta[0])  ]
                        ])

        R_y = np.array([[math.cos(theta[1]),    0.,      math.sin(theta[1])  ],
                        [0.,                     1.,      0.                   ],
                        [-math.sin(theta[1]),   0.,      math.cos(theta[1])  ]
                        ])

        R_z = np.array([[math.cos(theta[2]),    -math.sin(theta[2]),    0.],
                        [math.sin(theta[2]),    math.cos(theta[2]),     0.],
                        [0.,                     0.,                      1.]
                        ])

        R = np.dot(R_z, np.dot( R_y, R_x )) # .dot(np.diag([1, -1, -1]))
        # XYZ ZXY

        view_from_road = self.view_frame_from_device_frame.dot(R)
        return view_from_road


if __name__ == "__main__":
    rospy.init_node("fmtc_remote_tcp", anonymous=False)
    sN = subNode()
    pN = pubNode()
    rm = remote_manager()
    rm.loop()
    
